rootProject.name = "gilded-rose-kata"
